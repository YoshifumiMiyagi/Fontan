# Fontan 7-domain diffusion manifold

This folder-ready module refactors the 7-domain Fontan notebook into reusable classes.

## Main idea

The analysis is intentionally split into two responsibilities:

- `FontanManifold`: builds the complete-case reference manifold, freezes all reference transformations, performs fixed-reference Nyström projection, and runs stochastic multiple imputation.
- `FontanOutcomeAnalyzer`: fits logistic outcome models within each imputation and pools coefficients with Rubin's rules.

This separation makes it harder to accidentally refit the reference transformation on the full cohort.

## Minimal Colab usage

```python
from fontan_manifold import (
    FontanManifold,
    FontanOutcomeAnalyzer,
    default_sex_binary,
)

# raw = your original dataframe
df7 = FontanManifold.prepare_dataframe(raw)

model = FontanManifold(
    n_neighbors=50,
    n_dm=5,
    id_col="subj_id",
)

# Complete-case 7-domain reference is created inside fit()
model.fit(df7)

print("Reference N =", len(model.reference_df_))
display(model.self_validate(n_dm=3))

projection_long, mi_diagnostics = model.project_multiple_imputation(
    df7,
    n_imputations=20,
    seeds=range(1001, 1021),
    n_dm=3,
)

projection_summary = model.summarize_mi(
    projection_long,
    n_dm=3,
)

display(model.mi_stability(projection_long, n_dm=3))
display(model.complete_case_projection_validation(projection_long, n_dm=3))
```

## Outcome analysis

```python
clinical = df7.copy()

clinical["sex_binary"] = default_sex_binary(
    clinical["sex"]
)

analyzer = FontanOutcomeAnalyzer(
    id_col="subj_id"
)

mi_results = analyzer.fit_univariable_dm_models(
    projection_long=projection_long,
    clinical_df=clinical,
    dms=("DM1", "DM2", "DM3"),
    covariates=("fontan_year", "sex_binary"),
)

pooled = analyzer.pool(mi_results)

display(
    pooled[
        [
            "DM",
            "Outcome",
            "N",
            "Events",
            "OR_95CI",
            "P_value",
            "q_value",
            "FMI",
        ]
    ]
)
```

For the simultaneous DM model:

```python
multi_results = analyzer.fit_multivariable_dm_models(
    projection_long=projection_long,
    clinical_df=clinical,
    dms=("DM1", "DM2", "DM3"),
    covariates=("fontan_year", "sex_binary"),
)

pooled_multi = analyzer.pool(
    multi_results,
    fdr=False,
)
```

## Recommended GitHub structure

```text
fontan-manifold/
├── README.md
├── src/
│   └── fontan_manifold.py
├── notebooks/
│   ├── 01_build_reference.ipynb
│   ├── 02_mi_nystrom_projection.ipynb
│   └── 03_outcome_analysis.ipynb
├── results/
│   └── .gitkeep
├── tests/
│   └── test_fontan_manifold.py
├── requirements.txt
└── .gitignore
```

Do **not** commit PHN/raw patient-level data or derived files containing subject identifiers to a public repository. Keep the repository private unless every committed file is safe to disclose.

## Dependencies

```text
numpy
pandas
scipy
scikit-learn
statsmodels
```
