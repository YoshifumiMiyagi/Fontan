# Colab example: 7-domain Fontan manifold

from fontan_manifold import (
    FontanManifold,
    FontanOutcomeAnalyzer,
    default_sex_binary,
)

# 1. Prepare
df7 = FontanManifold.prepare_dataframe(raw)

# 2. Fit frozen complete-case reference
model = FontanManifold(n_neighbors=50, n_dm=5, id_col="subj_id")
model.fit(df7)

print("Full cohort N =", len(df7))
print("Reference N =", len(model.reference_df_))
display(model.self_validate(n_dm=3))

# 3. 20 stochastic MI + fixed-reference Nyström
projection_long, mi_diagnostics = model.project_multiple_imputation(
    df7,
    n_imputations=20,
    seeds=list(range(1001, 1021)),
    n_dm=3,
)

projection_summary = model.summarize_mi(projection_long, n_dm=3)

display(projection_summary.head())
display(model.mi_stability(projection_long, n_dm=3))
display(model.complete_case_projection_validation(projection_long, n_dm=3))

# 4. Clinical outcome analysis
clinical = df7.copy()
clinical["sex_binary"] = default_sex_binary(clinical["sex"])

analyzer = FontanOutcomeAnalyzer(id_col="subj_id")

individual = analyzer.fit_univariable_dm_models(
    projection_long,
    clinical,
    dms=("DM1", "DM2", "DM3"),
    covariates=("fontan_year", "sex_binary"),
)

pooled = analyzer.pool(individual, fdr=True)

display(
    pooled[
        ["DM", "Outcome", "N", "Events", "OR_95CI", "P_value", "q_value", "FMI"]
    ]
)

# 5. Multivariable DM1+DM2+DM3 model
multi_individual = analyzer.fit_multivariable_dm_models(
    projection_long,
    clinical,
    dms=("DM1", "DM2", "DM3"),
    covariates=("fontan_year", "sex_binary"),
)

pooled_multi = analyzer.pool(multi_individual, fdr=False)
display(pooled_multi)
